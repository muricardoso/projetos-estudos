class LandingDevotee{
    constructor(){
        this.initialize()
        this.btnClasses;
    }
    initialize(){
        this.copyright();
        this.modal();
        this.modalTerms();
        this.modalPolicy()
        // this.getJSONPolicy();
        this.openTabsClick();
        this.execClickTabs()
    }
    copyright(){
        let copyright = document.querySelector('#copyright')
        copyright.innerHTML=` Copyright © ${new Date().getFullYear()} Devotee. Todos direitos reservados.`
    }
    modalPolicy(){
        let modalId = document.querySelector("#my-modal-policy");
        let btn = "my-btn-policy";
        let close = "close-policy";
        console.log('s')
        this.modal(modalId, btn, close)
    }
    modalTerms(){
        let modalId = document.querySelector("#my-modal-terms");
        let btn = "my-btn-terms";
        let close = "close-terms";
        this.modal(modalId, btn, close)
    }
    modal(modalId, btn, close) {  
        document.addEventListener('click', (e) =>{
            let targetClass = e.target.classList.contains(btn);
            let targetClassClose = e.target.classList.contains(close);
            if(targetClass){
                modalId.style.display = "block";
            }
            if(targetClassClose){
                modalId.style.display = "none";
            }
		});
    }
    execClickTabs(){
        let btnClass = [];
        document.addEventListener('click', (e) =>{
            let targetClass = e.target.getAttribute('data-click');
            console.log(targetClass)
            switch (targetClass) {
                case 'click-terms':
                    btnClass[0] = 'click-terms'
                    break
                case 'click-policy-privacy':
                    btnClass[0] = 'click-policy-privacy'
                        break
                case 'click-policy-cookies':
                    btnClass[0] = 'click-policy-cookies'
                        break
                case 'click-procedures':
                    btnClass[0] = 'click-procedures'
                        break
                case 'click-security':
                    btnClass[0] = 'click-security'
                        break
                default:
                    break;
            }
        });  
        this.openTabsClick(btnClass)
    }
    
    openTabsClick(btnClass){
        document.addEventListener('click', (e) =>{
            this.hideTabs()
            let targetClass = e.target.classList.contains(btnClass);
            if(targetClass){
                this.openTabs(e, btnClass)
            }
            
		});
    }
    hideTabs(){
        let i, tabcontent
        tabcontent = document.getElementsByClassName("tabcontent");
        for (i = 0; i < tabcontent.length; i++) {
          tabcontent[i].style.display = "none";
        }
    }
    openTabs(evt, cityName) {
        
        var i, tabcontent,tablinks;
        tabcontent = document.getElementsByClassName("tabcontent");
        for (i = 0; i < tabcontent.length; i++) {
          tabcontent[i].style.display = "none";
        }
        tablinks = document.getElementsByClassName("tablinks");
        for (i = 0; i < tablinks.length; i++) {
          tablinks[i].className = tablinks[i].className.replace(" active", "");
        }
        document.getElementById(cityName).style.display = "block";
        evt.currentTarget.className += " active";
      }
    // getJSONPolicy(){
    //     let requestURL = 'https://github.com/muricardoso/Estudos/blob/master/politicas-de-privacidade.json';
    //     let request = new XMLHttpRequest();
    //     request.open('GET', requestURL);
    //     request.responseType = 'json';
    //     request.send();
    //     request.onload = function() {
    //         var policyPivacy = request.response;
    //         console.log(policyPivacy)
    //     }
        
    // }
}
