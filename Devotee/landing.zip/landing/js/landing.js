window.landing = new LandingDevotee()
